// Add your custom JavaScript for checkout here.
window.ecomPaymentApps = [1245, 111223]
